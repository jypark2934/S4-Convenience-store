/* global QUnit */

sap.ui.require(["project1/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
